print("print number 1: " .. 1)
print("print number 2: " .. 2)
print("print number 1337: " .. 1337)
print("print string test: " .. "test")
