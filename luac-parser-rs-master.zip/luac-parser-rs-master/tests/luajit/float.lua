print(160 * 160)
print(170 * 170)
print(180 * 180)
print(190 * 190)
print(200 * 200)

print(111122223333)
print(111122223333.4444)

print(var * -150)
print(0xFFFFFFFF123)
